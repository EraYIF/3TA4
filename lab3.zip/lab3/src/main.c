/**
******************************************************************************
  * @file    GPIO/GPIO_EXTI/Src/main.c
  * @author  MCD Application Team
  * @version V1.8.0
  * @date    21-April-2017
  * @brief   This example describes how to configure and use GPIOs through
  *          the STM32L4xx HAL API.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT(c) 2017 STMicroelectronics</center></h2>
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************


this program: 

1. This project needs the libraray file i2c_at2464c.c and its header file. 
2. in the i2c_at2464c.c, the I2C SCL and SDA pins are configured as PULLUP. so do not need to pull up resistors (even do not need the 100 ohm resisters).
NOTE: students can also configure the TimeStamp pin 	

*/




/* Includes ------------------------------------------------------------------*/
#include "main.h"

/** @addtogroup STM32L4xx_HAL_Examples
  * @{
  */

/** @addtogroup GPIO_EXTI
  * @{
  */

/* Private typedef -----------------------------------------------------------*/

/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef  pI2c_Handle;

RTC_HandleTypeDef RTCHandle;
RTC_DateTypeDef RTC_DateStructure;
RTC_TimeTypeDef RTC_TimeStructure;

Point_Typedef Point;
DoublePoint_Typedef Column;
DigitPosition_Typedef Position;

__IO HAL_StatusTypeDef Hal_status;  //HAL_ERROR, HAL_TIMEOUT, HAL_OK, of HAL_BUSY 

//uint32_t current_time=0;


//memory location to write to in the device
__IO uint16_t memLocation = 0x000A; //pick any location within range

  

char lcd_buffer[6];    // LCD display buffer
char timestring[10]={0}; 
char datestring[6]={0};

char seltime1[8];// two array used to store two timing results
char seltime2[8];
char timenow[8];   //for storing the timestructures
char datenow[16]; //for storing the datastructures
int leftsel=0;  //condition to show the current datastructures
int heldcond=0; //held condition check variable
uint8_t arr[100]; //Max change interval
int Value=0; //to access value to valriable
int Mode=0; //When you enter the 'Setting Mode', then to determine which part going to change
int sel_M=0; // detect if select button is pressed
char display[10]; // In setting mode,when you want to change value, show values

uint8_t wd, dd, mo, yy, ss, mm, hh; // for weekday, day, month, year, second, minute, hour
uint8_t ss1, ss2, mm1, mm2, hh1, hh2; // temporary variables

__IO uint32_t SEL_Pressed_StartTick;   //sysTick when the User button is pressed

__IO uint8_t push1pressed, push2pressed, leftpressed, rightpressed, uppressed, downpressed, selpressed;  // button pressed 

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Config(void);
static void Error_Handler(void);
static void EXTIE_Config(void);   //external port E buttons configure


void RTC_Config(void);
void RTC_AlarmAConfig(void);


/* Private functions ---------------------------------------------------------*/

/**
  * @brief  Main program
  * @param  None
  * @retval None
  */
int main(void)
{
  /* STM32L4xx HAL library initialization:
       - Configure the Flash prefetch
       - Systick timer is configured by default as source of time base, but user 
         can eventually implement his proper time base source (a general purpose 
         timer for example or other time source), keeping in mind that Time base 
         duration should be kept 1ms since PPP_TIMEOUT_VALUEs are defined and 
         handled in milliseconds basis.
       - Set NVIC Group Priority to 4 
       - Low Level Initialization
     */

	leftpressed=0;
	rightpressed=0;
	uppressed=0;
	downpressed=0;
	selpressed=0;
	push1pressed=0;
	push2pressed=0;
	/*     Initialize the arr              */
	for(uint8_t i=0;i<101;i++){
		arr[i]=i;
	}
	/*   Initialize the DateStructures - the day of the lab day */
	yy=18; //year 2018
	mo=10; //month october
	dd=29; //date 29th
	wd=01; //weekday monday
	

	HAL_Init();
	
	BSP_LED_Init(LED4);
	BSP_LED_Init(LED5);
  
	SystemClock_Config();   									
	
	HAL_InitTick(0x0000); //set the systick interrupt priority to the highest, !!!This line need to be after systemClock_config()

	
	BSP_LCD_GLASS_Init();
	
	BSP_JOY_Init(JOY_MODE_EXTI);


	EXTIE_Config();	

	
	BSP_LCD_GLASS_DisplayString((uint8_t*)"MT3TA4");	
	HAL_Delay(1000);


//configure real-time clock
	RTC_Config();
	
	RTC_AlarmAConfig();
	
	I2C_Init(&pI2c_Handle);


//*********************Testing I2C EEPROM------------------

	//the following variables are for testging I2C_EEPROM
	uint8_t data1 =0x67,  data2=0x68;
	uint8_t readData=0x00;
	uint16_t EE_status;


	/*EE_status=I2C_ByteWrite(&pI2c_Handle,EEPROM_ADDRESS, memLocation, data1);
  
  if(EE_status != HAL_OK)
  {
    I2C_Error(&pI2c_Handle);
  }
	
	
	BSP_LCD_GLASS_Clear();
	if (EE_status==HAL_OK) {
			BSP_LCD_GLASS_DisplayString((uint8_t*)"w 1 ok");
	}else
			BSP_LCD_GLASS_DisplayString((uint8_t*)"w 1 X");

	HAL_Delay(1000);
	
	EE_status=I2C_ByteWrite(&pI2c_Handle,EEPROM_ADDRESS, memLocation+1 , data2);
	
  if(EE_status != HAL_OK)
  {
    I2C_Error(&pI2c_Handle);
  }
	
	BSP_LCD_GLASS_Clear();
	if (EE_status==HAL_OK) {
			BSP_LCD_GLASS_DisplayString((uint8_t*)"w 2 ok");
	}else
			BSP_LCD_GLASS_DisplayString((uint8_t*)"w 2 X");

	HAL_Delay(1000);
	
	readData=I2C_ByteRead(&pI2c_Handle,EEPROM_ADDRESS, memLocation);

	BSP_LCD_GLASS_Clear();
	if (data1 == readData) {
			BSP_LCD_GLASS_DisplayString((uint8_t*)"r 1 ok");
	}else{
			BSP_LCD_GLASS_DisplayString((uint8_t*)"r 1 X");
	}	
	
	HAL_Delay(1000);
	
	readData=I2C_ByteRead(&pI2c_Handle,EEPROM_ADDRESS, memLocation+1);

	BSP_LCD_GLASS_Clear();
	if (data2 == readData) {
			BSP_LCD_GLASS_DisplayString((uint8_t*)"r 2 ok");
	}else{
			BSP_LCD_GLASS_DisplayString((uint8_t *)"r 2 X");
	}	

	HAL_Delay(1000);
	
*/

//******************************testing I2C EEPROM*****************************	
		

  /* Infinite loop */
  while (1)
  {
			//the joystick is pulled down. so the default status of the joystick is 0, when pressed, get status of 1. 
			//while the interrupt is configured at the falling edge---the moment the pressing is released, the interrupt is triggered.
			//therefore, the variable "selpressed==1" can not be used to make choice here.
			if (BSP_JOY_GetState() == JOY_SEL) {
					SEL_Pressed_StartTick=HAL_GetTick(); 
					while(BSP_JOY_GetState() == JOY_SEL) {  //while the selection button is pressed)	
	/*    When you hold the selecte button for greater than or equal to 1 s, LCD with display the datastructures      */
						if ((HAL_GetTick()-SEL_Pressed_StartTick)>=1000) {
							heldcond = 1;
							if(heldcond==1){
							sprintf(datenow,"wd %02d",wd);  //indicate it shows weekday now
							BSP_LCD_GLASS_Clear();
							BSP_LCD_GLASS_DisplayString((uint8_t*) datenow);
							HAL_Delay(800);
							sprintf(datenow,"dd %02d",dd);   //indicate it shows date now
							BSP_LCD_GLASS_Clear();
							BSP_LCD_GLASS_DisplayString((uint8_t*) datenow);
							HAL_Delay(800);
							sprintf(datenow,"mo %02d",mo);   //indicate it shows month now
							BSP_LCD_GLASS_Clear();
							BSP_LCD_GLASS_DisplayString((uint8_t*) datenow);
							HAL_Delay(800);
							sprintf(datenow,"yy %02d",yy);   //indicate it shows year now
							BSP_LCD_GLASS_Clear();
							BSP_LCD_GLASS_DisplayString((uint8_t*) datenow);
							HAL_Delay(800);
		
							heldcond=0; // go out of the if condition
							}
						} 
					}
			}					
//==============================================================			

//==============================================================		
/* push the external button 1 once,  store the current time into the external EEPROM once */			
			if (push1pressed==1)  {
				I2C_ByteWrite(&pI2c_Handle, EEPROM_ADDRESS, memLocation, ss);
				I2C_ByteWrite(&pI2c_Handle, EEPROM_ADDRESS, memLocation+1, mm);
				I2C_ByteWrite(&pI2c_Handle, EEPROM_ADDRESS, memLocation+2, hh);
				memLocation = memLocation+3; //relocate the memory Location for next time of store
				
					push1pressed=0;
			} 
//==============================================================			

//==============================================================		 
			if (selpressed ==1){
				
				selpressed = 0;
			}
			if (leftpressed==1) {
				/*  The left button to display the lastest two times that you stored in the external EEPROM  */
				if (leftsel == 1 && push2pressed==0){
				hh1 = I2C_ByteRead(&pI2c_Handle, EEPROM_ADDRESS, memLocation-1);
				mm1 = I2C_ByteRead(&pI2c_Handle, EEPROM_ADDRESS, memLocation-2);
				ss1 = I2C_ByteRead(&pI2c_Handle, EEPROM_ADDRESS, memLocation-3);
				hh2 = I2C_ByteRead(&pI2c_Handle, EEPROM_ADDRESS, memLocation-4);
				mm2 = I2C_ByteRead(&pI2c_Handle, EEPROM_ADDRESS, memLocation-5);
				ss2 = I2C_ByteRead(&pI2c_Handle, EEPROM_ADDRESS, memLocation-6);
				sprintf(seltime1, "%02d%02d%02d",hh1,mm1,ss1);
				sprintf(seltime2, "%02d%02d%02d",hh2,mm2,ss2);

				BSP_LCD_GLASS_Clear();
				BSP_LCD_GLASS_DisplayString((uint8_t*) seltime1);
				BSP_LCD_GLASS_DisplayChar((uint8_t*)&seltime1[1],POINT_OFF,DOUBLEPOINT_ON,(DigitPosition_Typedef)1);
				BSP_LCD_GLASS_DisplayChar((uint8_t*)&seltime1[3],POINT_OFF,DOUBLEPOINT_ON,(DigitPosition_Typedef)3);
				HAL_Delay(2000);
				BSP_LCD_GLASS_Clear();
				BSP_LCD_GLASS_DisplayString((uint8_t*) seltime2);
				BSP_LCD_GLASS_DisplayChar((uint8_t*)&seltime2[1],POINT_OFF,DOUBLEPOINT_ON,(DigitPosition_Typedef)1);
				BSP_LCD_GLASS_DisplayChar((uint8_t*)&seltime2[3],POINT_OFF,DOUBLEPOINT_ON,(DigitPosition_Typedef)3);
				HAL_Delay(2000);

					leftpressed=0;
				}
			}			
//==============================================================			

//==============================================================							
			if (push2pressed==1){  //Enter the 'Setting Mode'
				/*           Choose which part going to change         */
				/*  sel_M==0:: choose the part that you are going to change   */
				/*  sel_M==1:: choose the value that you want to modify*/
				/*  sel_M==2:: access the system with the value you chosen */
				/*Mode 0~6 represent Weekday, Date, Month, Year, Second, Minute and Hour respectively*/
							if(sel_M==0&& Mode==0){
									BSP_LCD_GLASS_Clear(); 
									BSP_LCD_GLASS_DisplayString((uint8_t *)"WEKDAY");
							}
							else if(sel_M==0&& Mode==1){
									BSP_LCD_GLASS_Clear(); 
									BSP_LCD_GLASS_DisplayString((uint8_t *)"_DATE_");
							}
							else if(sel_M==0&& Mode==2 ){
									BSP_LCD_GLASS_Clear(); 
									BSP_LCD_GLASS_DisplayString((uint8_t *)"MONTH_");
							}
							else if(sel_M==0&& Mode==3){
									BSP_LCD_GLASS_Clear(); 
									BSP_LCD_GLASS_DisplayString((uint8_t *)"_YEAY_");
							}
							else if(sel_M==0&& Mode==4){
									BSP_LCD_GLASS_Clear(); 
									BSP_LCD_GLASS_DisplayString((uint8_t *)"SECOND");
							}
							else if(sel_M==0&& Mode==5){
									BSP_LCD_GLASS_Clear(); 
									BSP_LCD_GLASS_DisplayString((uint8_t *)"MINUTE");
							}
							else if(sel_M==0&& Mode==6){
									BSP_LCD_GLASS_Clear(); 
									BSP_LCD_GLASS_DisplayString((uint8_t *)"_HOUR_");
							}
				/*   choose which value that you are going to access     */
								
				if(sel_M==1  && Mode ==0){
						if(Value==8){
							Value=1;
						}
						else if(Value==0){
							Value=7;
						}
						BSP_LCD_GLASS_Clear(); 
						sprintf(display,"%02d",arr[Value]);
						BSP_LCD_GLASS_DisplayString((uint8_t *) display);
						
				}
				else if(sel_M==1 && Mode ==1){
						if(Value==31){
							Value=1;
						}
						else if(Value==0){
							Value=30;
						}
						BSP_LCD_GLASS_Clear(); 
						sprintf(display,"0000%02d",arr[Value]);
						BSP_LCD_GLASS_DisplayString((uint8_t *)display);
				}
				else if(sel_M==1 && Mode ==2){
						if(Value==13){
							Value=1;
						}
						else if(Value==0){
							Value=12;
						}
						BSP_LCD_GLASS_Clear(); 
						sprintf(display,"0000%02d",arr[Value]);
						BSP_LCD_GLASS_DisplayString((uint8_t *)display);
				}
				else if(sel_M==1 && Mode ==3){
						if(Value==100){
							Value=0;
						}
						else if(Value< 0){
							Value=99;
						}
						BSP_LCD_GLASS_Clear(); 
						sprintf(display,"0000%02d",arr[Value]);
						BSP_LCD_GLASS_DisplayString((uint8_t *)display);
				}
				else if(sel_M==1 && Mode ==4){
						if(Value==60){
							Value=0;
						}
						else if(Value< 0){
							Value=59;
						}
						BSP_LCD_GLASS_Clear(); 
						sprintf(display,"0000%02d",arr[Value]);
						BSP_LCD_GLASS_DisplayString((uint8_t *)display);
				}
				else if(sel_M==1 && Mode ==5){
				
						if(Value==60){
							Value=0;
						}
						else if(Value< 0){
							Value=59;
						}
						BSP_LCD_GLASS_Clear(); 
						sprintf(display,"0000%02d",arr[Value]);
						BSP_LCD_GLASS_DisplayString((uint8_t *)display);
				}
				else if(sel_M==1 && Mode ==6){
						if(Value==24){
							Value=0;
						}
						else if(Value< 0){
							Value=23;
						}
						BSP_LCD_GLASS_Clear(); 
						sprintf(display,"0000%02d",arr[Value]);
						BSP_LCD_GLASS_DisplayString((uint8_t *)display);
				}
					/*        Access the values that you have chosen    */
				
									if(sel_M==2 && Mode ==0){
											wd=arr[Value];
										RTC_Config();
										RTC_AlarmAConfig();
											Value=0;
											sel_M=0;
										leftsel =0; 
									}
									else if(sel_M==2 && Mode ==1){
											dd=arr[Value];
										RTC_Config();
																RTC_AlarmAConfig();
											Value=0;
											sel_M=0;
										leftsel =0 ;
									}
									else if(sel_M==2 && Mode ==2){
											mo=arr[Value];
										RTC_Config();
																RTC_AlarmAConfig();
											Value=0;
											sel_M=0;
										leftsel =0 ;
									}
									else if(sel_M==2 && Mode ==3){
											yy=arr[Value];
										RTC_Config();
																RTC_AlarmAConfig();
											Value=0;
											sel_M=0;
										leftsel =0 ;
									}
									else if(sel_M==2 && Mode ==4){
											ss=arr[Value];
										RTC_Config();
																RTC_AlarmAConfig();
											Value=0;
											sel_M=0;
										leftsel =0 ;
									}
									else if(sel_M==2 && Mode ==5){
											mm=arr[Value];
										RTC_Config();
																RTC_AlarmAConfig();
											Value=0;
											sel_M=0;
										leftsel = 0;
									}
									else if(sel_M==2 && Mode ==6){
											hh=arr[Value];
										RTC_Config();
																RTC_AlarmAConfig();
											Value=0;
											sel_M=0;
										leftsel =0 ;
									}
								
					
			}
	}
}


/**
  * @brief  System Clock Configuration
  *         The system Clock is configured as follows :
  *            System Clock source            = MSI
  *            SYSCLK(Hz)                     = 4000000
  *            HCLK(Hz)                       = 4000000
  *            AHB Prescaler                  = 1
  *            APB1 Prescaler                 = 1
  *            APB2 Prescaler                 = 1
  *            MSI Frequency(Hz)              = 4000000
  *            Flash Latency(WS)              = 0
  * @param  None
  * @retval None
  */



void SystemClock_Config(void)
{ 
	RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};                                            

  // RTC requires to use HSE (or LSE or LSI, suspect these two are not available)
	//reading from RTC requires the APB clock is 7 times faster than HSE clock, 
	//so turn PLL on and use PLL as clock source to sysclk (so to APB)
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSE | RCC_OSCILLATORTYPE_MSI;     //RTC need either HSE, LSE or LSI           
  
	RCC_OscInitStruct.LSEState = RCC_LSE_ON;
	
	RCC_OscInitStruct.MSIState = RCC_MSI_ON;  
	RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_6; // RCC_MSIRANGE_6 is for 4Mhz. _7 is for 8 Mhz, _9 is for 16..., _10 is for 24 Mhz, _11 for 48Hhz
  RCC_OscInitStruct.MSICalibrationValue= RCC_MSICALIBRATION_DEFAULT;
  
	//RCC_OscInitStruct.PLL.PLLState = RCC_PLL_OFF;//RCC_PLL_NONE;

	RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_MSI;   //PLL source: either MSI, or HSI or HSE, but can not make HSE work.
  RCC_OscInitStruct.PLL.PLLM = 1;
  RCC_OscInitStruct.PLL.PLLN = 40; 
  RCC_OscInitStruct.PLL.PLLR = 2;  //2,4,6 or 8
  RCC_OscInitStruct.PLL.PLLP = 7;   // or 17.
  RCC_OscInitStruct.PLL.PLLQ = 4;   //2, 4,6, 0r 8  
	//the PLL will be MSI (4Mhz)*N /M/R = 

	if(HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    // Initialization Error 
    while(1);
  }

  // configure the HCLK, PCLK1 and PCLK2 clocks dividers 
  // Set 0 Wait State flash latency for 4Mhz 
  RCC_ClkInitStruct.ClockType = (RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2);
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK; //the freq of pllclk is MSI (4Mhz)*N /M/R = 80Mhz 
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
  
	
	if(HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)   //???
  {
    // Initialization Error 
    while(1);
  }

  // The voltage scaling allows optimizing the power consumption when the device is
  //   clocked below the maximum system frequency, to update the voltage scaling value
  //   regarding system frequency refer to product datasheet.  

  // Enable Power Control clock 
  __HAL_RCC_PWR_CLK_ENABLE();

  if(HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE2) != HAL_OK)
  {
    // Initialization Error 
    while(1);
  }

  // Disable Power Control clock   //why disable it?
  __HAL_RCC_PWR_CLK_DISABLE();      
}
//after RCC configuration, for timmer 2---7, which are one APB1, the TIMxCLK from RCC is 4MHz


void RTC_Config(void) {
	RTC_TimeTypeDef RTC_TimeStructure;
	RTC_DateTypeDef RTC_DateStructure;
	

	//****1:***** Enable the RTC domain access (enable wirte access to the RTC )
			//1.1: Enable the Power Controller (PWR) APB1 interface clock:
        __HAL_RCC_PWR_CLK_ENABLE();    
			//1.2:  Enable access to RTC domain 
				HAL_PWR_EnableBkUpAccess();    
			//1.3: Select the RTC clock source
				__HAL_RCC_RTC_CONFIG(RCC_RTCCLKSOURCE_LSE);    
				//RCC_RTCCLKSOURCE_LSI is defined in hal_rcc.h
	       // according to P9 of AN3371 Application Note, LSI's accuracy is not suitable for RTC application!!!! 
				
			//1.4: Enable RTC Clock
			__HAL_RCC_RTC_ENABLE();   //enable RTC --see note for the Macro in _hal_rcc.h---using this Marco requires 
																//the above three lines.
			
	
			//1.5  Enable LSI
			__HAL_RCC_LSI_ENABLE();   //need to enable the LSI !!!
																//defined in _rcc.c
			while (__HAL_RCC_GET_FLAG(RCC_FLAG_LSIRDY)==RESET) {}    //defined in rcc.c
	
			// for the above steps, please see the CubeHal UM1725, p616, section "Backup Domain Access" 	
				
				
				
	//****2.*****  Configure the RTC Prescaler (Asynchronous and Synchronous) and RTC hour 
        
		
		
		//**************************************************************************************				
				RTCHandle.Instance = RTC;
				RTCHandle.Init.HourFormat = RTC_HOURFORMAT_24;
				
				//set up to make RTC frequency be 1HZ
				RTCHandle.Init.AsynchPrediv = 0x7F; 
				RTCHandle.Init.SynchPrediv = 0xFF; 
				
				
				RTCHandle.Init.OutPut = RTC_OUTPUT_ALARMA;
				RTCHandle.Init.OutPutPolarity = RTC_OUTPUT_POLARITY_HIGH;
				RTCHandle.Init.OutPutType = RTC_OUTPUT_TYPE_OPENDRAIN;
				
			
				if(HAL_RTC_Init(&RTCHandle) != HAL_OK)
				{
					BSP_LCD_GLASS_Clear(); 
					BSP_LCD_GLASS_DisplayString((uint8_t *)"RT I X"); 	
				}

	
	
	
	//****3.***** init the timestructures  and date	structures
		//****************************************************************************************		
				RTC_DateStructure.Year = yy;
				RTC_DateStructure.Month = mo;
				RTC_DateStructure.Date = dd;
				RTC_DateStructure.WeekDay = wd;
				
				if(HAL_RTC_SetDate(&RTCHandle,&RTC_DateStructure,RTC_FORMAT_BIN) != HAL_OK)   //BIN format is better 
															//before, must set in BCD format and read in BIN format!!
				{
					BSP_LCD_GLASS_Clear();
					BSP_LCD_GLASS_DisplayString((uint8_t *)"D I X");
				} 
  
				
				RTC_TimeStructure.Hours = hh;  
				RTC_TimeStructure.Minutes = mm; 
				RTC_TimeStructure.Seconds = ss;
				RTC_TimeStructure.TimeFormat = RTC_HOURFORMAT_24;
				RTC_TimeStructure.DayLightSaving = RTC_DAYLIGHTSAVING_NONE;
				RTC_TimeStructure.StoreOperation = RTC_STOREOPERATION_RESET;
			
				
				if(HAL_RTC_SetTime(&RTCHandle,&RTC_TimeStructure,RTC_FORMAT_BIN) != HAL_OK)   //BIN format is better
																																					//before, must set in BCD format and read in BIN format!!
				{
					BSP_LCD_GLASS_Clear();
					BSP_LCD_GLASS_DisplayString((uint8_t *)"T I X");
				}	
	  




				
			__HAL_RTC_TAMPER1_DISABLE(&RTCHandle);
			__HAL_RTC_TAMPER2_DISABLE(&RTCHandle);	
				//Optionally, a tamper event can cause a timestamp to be recorded. ---P802 of RM0090
				//Timestamp on tamper event
				//With TAMPTS set to �1 , any tamper event causes a timestamp to occur. In this case, either
				//the TSF bit or the TSOVF bit are set in RTC_ISR, in the same manner as if a normal
				//timestamp event occurs. The affected tamper flag register (TAMP1F, TAMP2F) is set at the
				//same time that TSF or TSOVF is set. ---P802, about Tamper detection
				//-------that is why need to disable this two tamper interrupts. Before disable these two, when program start, there is always a timestamp interrupt.
				//----also, these two disable function can not be put in the TSConfig().---put there will make  the program freezed when start. the possible reason is
				//-----one the RTC is configured, changing the control register again need to lock and unlock RTC and disable write protection.---See Alarm disable/Enable 
				//---function.
				
			HAL_RTC_WaitForSynchro(&RTCHandle);	
			//To read the calendar through the shadow registers after Calendar initialization,
			//		calendar update or after wake-up from low power modes the software must first clear
			//the RSF flag. The software must then wait until it is set again before reading the
			//calendar, which means that the calendar registers have been correctly copied into the
			//RTC_TR and RTC_DR shadow registers.The HAL_RTC_WaitForSynchro() function
			//implements the above software sequence (RSF clear and RSF check).	
}


void RTC_AlarmAConfig(void)
{
	RTC_AlarmTypeDef RTC_Alarm_Structure;

	//********************************************************************************
	
	RTC_Alarm_Structure.Alarm = RTC_ALARM_A;
  RTC_Alarm_Structure.AlarmMask = RTC_ALARMMASK_ALL;
	
	
	//********************************************************************************	
  
  if(HAL_RTC_SetAlarm_IT(&RTCHandle,&RTC_Alarm_Structure,RTC_FORMAT_BCD) != HAL_OK)
  {
			BSP_LCD_GLASS_Clear(); 
			BSP_LCD_GLASS_DisplayString((uint8_t *)"A S X");
  }

	__HAL_RTC_ALARM_CLEAR_FLAG(&RTCHandle, RTC_FLAG_ALRAF); //without this line, sometimes(SOMETIMES, when first time to use the alarm interrupt)
																			//the interrupt handler will not work!!! 		

		//need to set/enable the NVIC for RTC_Alarm_IRQn!!!!
	HAL_NVIC_EnableIRQ(RTC_Alarm_IRQn);   
	HAL_NVIC_SetPriority(RTC_Alarm_IRQn, 3, 0);  //not important ,but it is better not use the same prio as the systick
	
}

//You may need to disable and enable the RTC Alarm at some moment in your application
HAL_StatusTypeDef  RTC_AlarmA_IT_Disable(RTC_HandleTypeDef *hrtc) 
{ 
 	// Process Locked  
	__HAL_LOCK(hrtc);
  
  hrtc->State = HAL_RTC_STATE_BUSY;
  
  // Disable the write protection for RTC registers 
  __HAL_RTC_WRITEPROTECTION_DISABLE(hrtc);
  
  // __HAL_RTC_ALARMA_DISABLE(hrtc);
    
   // In case of interrupt mode is used, the interrupt source must disabled 
   __HAL_RTC_ALARM_DISABLE_IT(hrtc, RTC_IT_ALRA);


 // Enable the write protection for RTC registers 
  __HAL_RTC_WRITEPROTECTION_ENABLE(hrtc);
  
  hrtc->State = HAL_RTC_STATE_READY; 
  
  // Process Unlocked 
  __HAL_UNLOCK(hrtc);  
}


HAL_StatusTypeDef  RTC_AlarmA_IT_Enable(RTC_HandleTypeDef *hrtc) 
{	
	// Process Locked  
	__HAL_LOCK(hrtc);	
  hrtc->State = HAL_RTC_STATE_BUSY;
  
  // Disable the write protection for RTC registers 
  __HAL_RTC_WRITEPROTECTION_DISABLE(hrtc);
  
  // __HAL_RTC_ALARMA_ENABLE(hrtc);
    
   // In case of interrupt mode is used, the interrupt source must disabled 
   __HAL_RTC_ALARM_ENABLE_IT(hrtc, RTC_IT_ALRA);


 // Enable the write protection for RTC registers 
  __HAL_RTC_WRITEPROTECTION_ENABLE(hrtc);
  
  hrtc->State = HAL_RTC_STATE_READY; 
  
  // Process Unlocked 
  __HAL_UNLOCK(hrtc);  

}

static void EXTIE_Config(void)
{
  GPIO_InitTypeDef   GPIO_InitStructure;

  // Enable GPIOE clock 
  __HAL_RCC_GPIOE_CLK_ENABLE();

  // Configure PE.14 pin as input floating 
  GPIO_InitStructure.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStructure.Pull = GPIO_PULLDOWN;
  GPIO_InitStructure.Pin = GPIO_PIN_14|GPIO_PIN_15;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStructure);

  // Enable and set EXTI line 14 Interrupt to the lowest priority 
  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 2, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);
}


/**
  * @brief EXTI line detection callbacks
  * @param GPIO_Pin: Specifies the pins connected EXTI line
  * @retval None
  */


void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
  switch (GPIO_Pin) {
			case GPIO_PIN_0: 		               //SELECT button	
				/*when push2pressed==0 :: you are not in the setting mode*/
						if(push2pressed==0){
						selpressed=1;	
						}
			 /*when push2pressed==1 ::  you are in the setting mode. So push the select button means change */
			 /*sel_M is the part that you are going to change */
						if(push2pressed==1){
							sel_M=(sel_M+1);
						}
						break;	
			case GPIO_PIN_1:     //left button	
				/*when push2pressed==0 :: you are not in the setting mode*/
							if(push2pressed==0){
								leftpressed=1;
								leftsel = (leftsel+1)%2; //used as a condion to check run I2C code or not when leftpressed=1
							}
							
				/*when push2pressed==1 ::  you are in the setting mode. So push the left button means change */
				/*the part that you are going to change */
							if(push2pressed==1){
								Mode=(Mode+1)%7;//later add if cond to check state5 left press conflicts
							}
							break;
			case GPIO_PIN_2:    //right button						  to play again.
				/*when push2pressed==1 ::  you are in the setting mode. So push the right button means change */
				/*the part that you are going to change */
							if(push2pressed==1){
								Mode--;
								if(Mode<0){
									Mode=6; //we only have 7 mode, weekday, date, month, year, minute, second and year
								}
							}
							break;
			case GPIO_PIN_3:    //up button								
							if(push2pressed==1){
							Value++;    // add current value with 1 which would show up in change value stage inside time setting mode
							}
							break;
			
			case GPIO_PIN_5:    //down button							
							if(push2pressed==1){
							Value--;    //minus current value with 1 which would show up in change value stage inside time setting mode
							}
							break;
			case GPIO_PIN_15:		//push2 button
							push2pressed=(push2pressed+1)%2;  //determine whether you are in setting mode or not. 1 is in, 0 is not.
							if(push2pressed == 0) sel_M=0; //when you exit from the setting mode, initial the variable sel_M
							break;
			case GPIO_PIN_14:    //push1 button							
							push1pressed=1;      //push once, save the current time once into the external EEPROM
							break;
			default://
						//default
						break;
	  } 
}


void RTC_TimeShow(void)
{
	/*****  To show the time now ********/
	if (leftsel == 0 && heldcond == 0 && push2pressed==0){
	BSP_LCD_GLASS_Clear();
	HAL_RTC_GetTime(&RTCHandle,&RTC_TimeStructure,RTC_FORMAT_BIN);
	HAL_RTC_GetDate(&RTCHandle,&RTC_DateStructure,RTC_FORMAT_BIN); //After HAL_RTC_GetTime to unlock values in the calendar
	/**assign values to corresponding variables**/
	hh = RTC_TimeStructure.Hours;
	mm = RTC_TimeStructure.Minutes;
	ss = RTC_TimeStructure.Seconds;
	wd = RTC_DateStructure.WeekDay;
	dd = RTC_DateStructure.Date;
	mo = RTC_DateStructure.Month;
	yy = RTC_DateStructure.Year;
	
	//print current time on LCD
	sprintf(timenow,"%02d%02d%02d",hh,mm,ss);
	BSP_LCD_GLASS_DisplayString((uint8_t*) timenow);
	//Display colons on LCD
	BSP_LCD_GLASS_DisplayChar((uint8_t*)&timenow[1],POINT_OFF,DOUBLEPOINT_ON,(DigitPosition_Typedef)1);
	BSP_LCD_GLASS_DisplayChar((uint8_t*)&timenow[3],POINT_OFF,DOUBLEPOINT_ON,(DigitPosition_Typedef)3);
	}
}	
void HAL_RTC_AlarmAEventCallback(RTC_HandleTypeDef *hrtc)
{
  BSP_LED_Toggle(LED5);
	RTC_TimeShow();
	
}

static void Error_Handler(void)
{
  /* Turn LED4 on */
  BSP_LED_On(LED4);
  while(1)
  {
  }
}




#ifdef  USE_FULL_ASSERT

/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(char *file, uint32_t line)
{
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif

/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
